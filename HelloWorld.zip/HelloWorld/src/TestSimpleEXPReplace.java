import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author Lisa May 28, 2018 TestSimpleEXPReplace.java 
 */

public class TestSimpleEXPReplace {

	@Test
	public void test1() {
		assertEquals(0, new SimpleEXPReplace().simpleExpError());
	}
}
