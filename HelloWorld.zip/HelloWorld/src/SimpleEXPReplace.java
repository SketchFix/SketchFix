/**
 * @author Lisa SimpleEXPReplace.java 
 */

public class SimpleEXPReplace {

	public int simpleExpError() {
		int a = 0; 
		int b = 1;
		//expect to have int c = a;
		int c = b;
		return c;
	}
}
