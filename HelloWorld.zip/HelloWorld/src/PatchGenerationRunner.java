import edSketch.repair.config.ConfigReader.ConfigType;
import edSketch.repair.staticAnalyzer.model.StaticAnalyzer;

/**
 * @author Lisa May 28, 2018 PatchGenerationRunner.java
 */

public class PatchGenerationRunner {

	public static void main(String[] args) {
		StaticAnalyzer analyzer = new StaticAnalyzer();
		analyzer.setConfigFile(ConfigType.SIMPLE, "SimpleConfig.txt");
		analyzer.setFaultLocation("SimpleEXPReplace:11", 0);
	}

}
